#ifndef ORDENAMIENTOS_H
#define ORDENAMIENTOS_H

void selectionSort(int arreglo[], int n);
void InsertionSort(int lista[], int n);
void BubbleSort(int lista[], int n);
//Nuevos:
void quickSort(int arr[], int low, int high);
void HeapSort(int* A, int size);
#endif