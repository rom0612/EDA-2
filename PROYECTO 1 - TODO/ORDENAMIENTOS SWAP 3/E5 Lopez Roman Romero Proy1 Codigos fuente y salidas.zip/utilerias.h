#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED
#define MAX 1000
//swap
void swap(int *a, int *b);
//Crear el arreglo aleatorio
void generarArregloAleatorio(int arreglo[], int tamaño);

#endif // MENU_H_INCLUDED